import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import type { 
  PsychometricState, 
  HEXACOResponse, 
  DASSResponse, 
  HEXACOScores, 
  DASSScores, 
  StabilityFlags,
  PsychometricProfile 
} from '../types/psychometric';
import { PsychometricValidator } from '../validation/psychometricSchemas';
import { ScoringAlgorithm } from '../algorithms/ScoringAlgorithm';

// Initial state for HEXACO responses (60 items)
const initialHexacoResponses: HEXACOResponse[] = Array.from({ length: 60 }, (_, i) => ({
  id: i + 1,
  response: -1, // -1 indicates unanswered
}));

// Initial state for DASS responses (21 items)
const initialDassResponses: DASSResponse[] = Array.from({ length: 21 }, (_, i) => ({
  id: i + 1,
  response: -1, // -1 indicates unanswered
}));

export interface ExtendedPsychometricState extends PsychometricState {
  // Additional computed states
  hexacoProgress: number; // 0-100
  dassProgress: number;  // 0-100
  totalProgress: number; // 0-100
  
  // Response validity tracking
  hexacoResponseValidity: boolean[];
  dassResponseValidity: boolean[];
  
  // Scoring cache
  lastScoredAt: Date | null;
  scoringCache: {
    hexacoScores: HEXACOScores | null;
    dassScores: DASSScores | null;
    stabilityFlags: StabilityFlags | null;
  };
  
  // Assessment flow control
  currentSection: 'intro' | 'hexaco' | 'dass' | 'results' | 'complete';
  showValidationErrors: boolean;
  
  // Advanced analytics
  responseTimes: number[]; // Response time for each question in milliseconds
  averageResponseTime: number;
  
  // Export/Import functionality
  exportProfile: () => PsychometricProfile | null;
  importProfile: (profile: PsychometricProfile) => boolean;
  
  // Batch operations
  setHexacoResponsesBatch: (responses: { id: number; response: number }[]) => void;
  setDassResponsesBatch: (responses: { id: number; response: number }[]) => void;
  
  // Advanced validation
  validateAllResponses: () => { isValid: boolean; errors: string[] };
  getUnansweredQuestions: () => { hexaco: number[]; dass: number[] };
  
  // Progress tracking
  markQuestionAsAnswered: (scale: 'hexaco' | 'dass', questionId: number) => void;
  markQuestionAsUnanswered: (scale: 'hexaco' | 'dass', questionId: number) => void;
  
  // State persistence
  saveToLocalStorage: () => void;
  loadFromLocalStorage: () => boolean;
  clearLocalStorage: () => void;
}

export const usePsychometricStore = create<ExtendedPsychometricState>()(
  devtools(
    (set, get) => ({
      // Basic state
      hexacoResponses: initialHexacoResponses,
      dassResponses: initialDassResponses,
      hexacoScores: null,
      dassScores: null,
      stabilityFlags: null,
      currentScale: null,
      currentQuestion: 1,
      isComplete: false,
      isValid: false,
      startedAt: null,
      completedAt: null,
      lastUpdated: null,

      // Extended state
      hexacoProgress: 0,
      dassProgress: 0,
      totalProgress: 0,
      hexacoResponseValidity: Array(60).fill(false),
      dassResponseValidity: Array(21).fill(false),
      lastScoredAt: null,
      scoringCache: {
        hexacoScores: null,
        dassScores: null,
        stabilityFlags: null,
      },
      currentSection: 'intro',
      showValidationErrors: false,
      responseTimes: Array(81).fill(0), // 60 + 21 = 81 total questions
      averageResponseTime: 0,

      // Basic setters
      setHexacoResponse: (id: number, response: number) => {
        const startTime = Date.now();
        
        set((state) => {
          // Validate response
          const validation = PsychometricValidator.validateResponseValue(response, 'hexaco');
          const idValidation = PsychometricValidator.validateQuestionId(id, 'hexaco');
          
          if (!validation.isValid || !idValidation.isValid) {
            if (state.showValidationErrors) {
              console.error('Invalid HEXACO response:', { id, response, validation, idValidation });
            }
            return state;
          }

          const newResponses = [...state.hexacoResponses];
          const index = newResponses.findIndex(r => r.id === id);
          
          if (index !== -1) {
            newResponses[index] = { id, response };
            
            // Update validity
            const newValidity = [...state.hexacoResponseValidity];
            newValidity[index] = true;
            
            // Update response time
            const newResponseTimes = [...state.responseTimes];
            const questionIndex = id - 1; // HEXACO questions are 1-60
            if (newResponseTimes[questionIndex] === 0) {
              newResponseTimes[questionIndex] = Date.now() - startTime;
            }
            
            // Calculate progress
            const answeredCount = newResponses.filter(r => r.response >= 0).length;
            const progress = (answeredCount / 60) * 100;
            
            return {
              hexacoResponses: newResponses,
              hexacoResponseValidity: newValidity,
              hexacoProgress: progress,
              totalProgress: (progress + state.dassProgress) / 2,
              lastUpdated: new Date(),
              responseTimes: newResponseTimes,
            };
          }
          
          return state;
        });
      },

      setDassResponse: (id: number, response: number) => {
        const startTime = Date.now();
        
        set((state) => {
          // Validate response
          const validation = PsychometricValidator.validateResponseValue(response, 'dass');
          const idValidation = PsychometricValidator.validateQuestionId(id, 'dass');
          
          if (!validation.isValid || !idValidation.isValid) {
            if (state.showValidationErrors) {
              console.error('Invalid DASS response:', { id, response, validation, idValidation });
            }
            return state;
          }

          const newResponses = [...state.dassResponses];
          const index = newResponses.findIndex(r => r.id === id);
          
          if (index !== -1) {
            newResponses[index] = { id, response };
            
            // Update validity
            const newValidity = [...state.dassResponseValidity];
            newValidity[index] = true;
            
            // Update response time
            const newResponseTimes = [...state.responseTimes];
            const questionIndex = 60 + (id - 1); // DASS questions start after HEXACO (60-80)
            if (newResponseTimes[questionIndex] === 0) {
              newResponseTimes[questionIndex] = Date.now() - startTime;
            }
            
            // Calculate progress
            const answeredCount = newResponses.filter(r => r.response >= 0).length;
            const progress = (answeredCount / 21) * 100;
            
            return {
              dassResponses: newResponses,
              dassResponseValidity: newValidity,
              dassProgress: progress,
              totalProgress: (state.hexacoProgress + progress) / 2,
              lastUpdated: new Date(),
              responseTimes: newResponseTimes,
            };
          }
          
          return state;
        });
      },

      setHexacoResponses: (responses: HEXACOResponse[]) => {
        set((state) => {
          try {
            PsychometricValidator.validateHexacoResponses(responses);
          } catch (error) {
            console.error('Invalid HEXACO responses array:', error);
            return state;
          }

          const validity = responses.map(r => r.response >= 0);
          const answeredCount = responses.filter(r => r.response >= 0).length;
          const progress = (answeredCount / 60) * 100;

          return {
            hexacoResponses: responses,
            hexacoResponseValidity: validity,
            hexacoProgress: progress,
            totalProgress: (progress + state.dassProgress) / 2,
            lastUpdated: new Date(),
          };
        });
      },

      setDassResponses: (responses: DASSResponse[]) => {
        set((state) => {
          try {
            PsychometricValidator.validateDassResponses(responses);
          } catch (error) {
            console.error('Invalid DASS responses array:', error);
            return state;
          }

          const validity = responses.map(r => r.response >= 0);
          const answeredCount = responses.filter(r => r.response >= 0).length;
          const progress = (answeredCount / 21) * 100;

          return {
            dassResponses: responses,
            dassResponseValidity: validity,
            dassProgress: progress,
            totalProgress: (state.hexacoProgress + progress) / 2,
            lastUpdated: new Date(),
          };
        });
      },

      calculateScores: () => {
        set((state) => {
          const completeness = ScoringAlgorithm.validateResponseCompleteness(
            state.hexacoResponses.filter(r => r.response >= 0),
            state.dassResponses.filter(r => r.response >= 0)
          );

          if (!completeness.isComplete) {
            console.warn('Attempting to calculate scores with incomplete responses:', completeness);
            return state;
          }

          try {
            const validHexacoResponses = state.hexacoResponses.filter(r => r.response >= 0);
            const validDassResponses = state.dassResponses.filter(r => r.response >= 0);

            const scores = ScoringAlgorithm.calculateScores({
              hexacoResponses: validHexacoResponses,
              dassResponses: validDassResponses,
            });

            const isNowComplete = completeness.isHexacoComplete && completeness.isDassComplete;

            return {
              hexacoScores: scores.hexacoScores,
              dassScores: scores.dassScores,
              stabilityFlags: scores.stabilityFlags,
              scoringCache: {
                hexacoScores: scores.hexacoScores,
                dassScores: scores.dassScores,
                stabilityFlags: scores.stabilityFlags,
              },
              lastScoredAt: new Date(),
              isComplete: isNowComplete,
              completedAt: isNowComplete ? new Date() : state.completedAt,
              isValid: true,
            };
          } catch (error) {
            console.error('Error calculating scores:', error);
            return {
              ...state,
              isValid: false,
            };
          }
        });
      },

      resetAssessment: () => {
        set({
          hexacoResponses: initialHexacoResponses,
          dassResponses: initialDassResponses,
          hexacoScores: null,
          dassScores: null,
          stabilityFlags: null,
          currentScale: null,
          currentQuestion: 1,
          isComplete: false,
          isValid: false,
          startedAt: null,
          completedAt: null,
          lastUpdated: null,
          hexacoProgress: 0,
          dassProgress: 0,
          totalProgress: 0,
          hexacoResponseValidity: Array(60).fill(false),
          dassResponseValidity: Array(21).fill(false),
          lastScoredAt: null,
          scoringCache: {
            hexacoScores: null,
            dassScores: null,
            stabilityFlags: null,
          },
          currentSection: 'intro',
          showValidationErrors: false,
          responseTimes: Array(81).fill(0),
          averageResponseTime: 0,
        });
      },

      setCurrentScale: (scale: 'hexaco' | 'dass') => {
        set((state) => ({
          currentScale: scale,
          currentQuestion: 1,
          startedAt: state.startedAt || new Date(),
          lastUpdated: new Date(),
        }));
      },

      setCurrentQuestion: (question: number) => {
        set((state) => ({
          currentQuestion: question,
          lastUpdated: new Date(),
        }));
      },

      validateResponses: () => {
        const state = get();
        const validation = PsychometricValidator.validateCompleteResponses(
          state.hexacoResponses,
          state.dassResponses
        );
        
        set({ isValid: validation.isValid });
        return validation.isValid;
      },

      // Extended functionality
      exportProfile: () => {
        const state = get();
        
        if (!state.isComplete || !state.hexacoScores || !state.dassScores || !state.stabilityFlags) {
          return null;
        }

        return {
          hexacoResponses: state.hexacoResponses,
          dassResponses: state.dassResponses,
          hexacoScores: state.hexacoScores,
          dassScores: state.dassScores,
          stabilityFlags: state.stabilityFlags,
          completedAt: state.completedAt,
          lastUpdated: state.lastUpdated,
          isValid: state.isValid,
        };
      },

      importProfile: (profile: PsychometricProfile) => {
        try {
          const validation = PsychometricValidator.validateCompleteProfile(profile);
          
          if (!validation) {
            console.error('Invalid profile format');
            return false;
          }

          const hexacoValidity = profile.hexacoResponses.map(r => r.response >= 0);
          const dassValidity = profile.dassResponses.map(r => r.response >= 0);
          
          const hexacoAnswered = profile.hexacoResponses.filter(r => r.response >= 0).length;
          const dassAnswered = profile.dassResponses.filter(r => r.response >= 0).length;
          
          const hexacoProgress = (hexacoAnswered / 60) * 100;
          const dassProgress = (dassAnswered / 21) * 100;

          set({
            hexacoResponses: profile.hexacoResponses,
            dassResponses: profile.dassResponses,
            hexacoScores: profile.hexacoScores,
            dassScores: profile.dassScores,
            stabilityFlags: profile.stabilityFlags,
            hexacoResponseValidity: hexacoValidity,
            dassResponseValidity: dassValidity,
            hexacoProgress,
            dassProgress,
            totalProgress: (hexacoProgress + dassProgress) / 2,
            completedAt: profile.completedAt,
            lastUpdated: profile.lastUpdated,
            isValid: profile.isValid,
            isComplete: hexacoAnswered === 60 && dassAnswered === 21,
            scoringCache: {
              hexacoScores: profile.hexacoScores,
              dassScores: profile.dassScores,
              stabilityFlags: profile.stabilityFlags,
            },
          });

          return true;
        } catch (error) {
          console.error('Error importing profile:', error);
          return false;
        }
      },

      setHexacoResponsesBatch: (responses: { id: number; response: number }[]) => {
        set((state) => {
          const newResponses = [...state.hexacoResponses];
          const newValidity = [...state.hexacoResponseValidity];
          
          responses.forEach(({ id, response }) => {
            const validation = PsychometricValidator.validateResponseValue(response, 'hexaco');
            const idValidation = PsychometricValidator.validateQuestionId(id, 'hexaco');
            
            if (validation.isValid && idValidation.isValid) {
              const index = newResponses.findIndex(r => r.id === id);
              if (index !== -1) {
                newResponses[index] = { id, response };
                newValidity[index] = response >= 0;
              }
            }
          });
          
          const answeredCount = newResponses.filter(r => r.response >= 0).length;
          const progress = (answeredCount / 60) * 100;

          return {
            hexacoResponses: newResponses,
            hexacoResponseValidity: newValidity,
            hexacoProgress: progress,
            totalProgress: (progress + state.dassProgress) / 2,
            lastUpdated: new Date(),
          };
        });
      },

      setDassResponsesBatch: (responses: { id: number; response: number }[]) => {
        set((state) => {
          const newResponses = [...state.dassResponses];
          const newValidity = [...state.dassResponseValidity];
          
          responses.forEach(({ id, response }) => {
            const validation = PsychometricValidator.validateResponseValue(response, 'dass');
            const idValidation = PsychometricValidator.validateQuestionId(id, 'dass');
            
            if (validation.isValid && idValidation.isValid) {
              const index = newResponses.findIndex(r => r.id === id);
              if (index !== -1) {
                newResponses[index] = { id, response };
                newValidity[index] = response >= 0;
              }
            }
          });
          
          const answeredCount = newResponses.filter(r => r.response >= 0).length;
          const progress = (answeredCount / 21) * 100;

          return {
            dassResponses: newResponses,
            dassResponseValidity: newValidity,
            dassProgress: progress,
            totalProgress: (state.hexacoProgress + progress) / 2,
            lastUpdated: new Date(),
          };
        });
      },

      validateAllResponses: () => {
        const state = get();
        const errors: string[] = [];

        // Check HEXACO responses
        state.hexacoResponses.forEach((response, index) => {
          if (response.response < 0 || response.response > 5) {
            errors.push(`HEXACO Question ${response.id}: Invalid response value ${response.response}`);
          }
        });

        // Check DASS responses
        state.dassResponses.forEach((response, index) => {
          if (response.response < 0 || response.response > 3) {
            errors.push(`DASS Question ${response.id}: Invalid response value ${response.response}`);
          }
        });

        const isValid = errors.length === 0;
        set({ isValid });
        
        return { isValid, errors };
      },

      getUnansweredQuestions: () => {
        const state = get();
        const hexaco = state.hexacoResponses
          .filter(r => r.response < 0)
          .map(r => r.id);
        const dass = state.dassResponses
          .filter(r => r.response < 0)
          .map(r => r.id);
        
        return { hexaco, dass };
      },

      markQuestionAsAnswered: (scale: 'hexaco' | 'dass', questionId: number) => {
        set((state) => {
          if (scale === 'hexaco') {
            const newValidity = [...state.hexacoResponseValidity];
            const index = questionId - 1;
            if (index >= 0 && index < 60) {
              newValidity[index] = true;
              return { hexacoResponseValidity: newValidity };
            }
          } else {
            const newValidity = [...state.dassResponseValidity];
            const index = questionId - 1;
            if (index >= 0 && index < 21) {
              newValidity[index] = true;
              return { dassResponseValidity: newValidity };
            }
          }
          return state;
        });
      },

      markQuestionAsUnanswered: (scale: 'hexaco' | 'dass', questionId: number) => {
        set((state) => {
          if (scale === 'hexaco') {
            const newValidity = [...state.hexacoResponseValidity];
            const newResponses = [...state.hexacoResponses];
            const index = questionId - 1;
            
            if (index >= 0 && index < 60) {
              newValidity[index] = false;
              newResponses[index] = { id: questionId, response: -1 };
              
              const answeredCount = newResponses.filter(r => r.response >= 0).length;
              const progress = (answeredCount / 60) * 100;
              
              return {
                hexacoResponseValidity: newValidity,
                hexacoResponses: newResponses,
                hexacoProgress: progress,
                totalProgress: (progress + state.dassProgress) / 2,
                lastUpdated: new Date(),
              };
            }
          } else {
            const newValidity = [...state.dassResponseValidity];
            const newResponses = [...state.dassResponses];
            const index = questionId - 1;
            
            if (index >= 0 && index < 21) {
              newValidity[index] = false;
              newResponses[index] = { id: questionId, response: -1 };
              
              const answeredCount = newResponses.filter(r => r.response >= 0).length;
              const progress = (answeredCount / 21) * 100;
              
              return {
                dassResponseValidity: newValidity,
                dassResponses: newResponses,
                dassProgress: progress,
                totalProgress: (state.hexacoProgress + progress) / 2,
                lastUpdated: new Date(),
              };
            }
          }
          return state;
        });
      },

      saveToLocalStorage: () => {
        try {
          const state = get();
          const dataToSave = {
            hexacoResponses: state.hexacoResponses,
            dassResponses: state.dassResponses,
            hexacoScores: state.hexacoScores,
            dassScores: state.dassScores,
            stabilityFlags: state.stabilityFlags,
            currentScale: state.currentScale,
            currentQuestion: state.currentQuestion,
            isComplete: state.isComplete,
            isValid: state.isValid,
            startedAt: state.startedAt,
            completedAt: state.completedAt,
            lastUpdated: state.lastUpdated,
            hexacoProgress: state.hexacoProgress,
            dassProgress: state.dassProgress,
            totalProgress: state.totalProgress,
            currentSection: state.currentSection,
          };
          
          localStorage.setItem('psychometric-assessment', JSON.stringify(dataToSave));
          return true;
        } catch (error) {
          console.error('Error saving to localStorage:', error);
          return false;
        }
      },

      loadFromLocalStorage: () => {
        try {
          const savedData = localStorage.getItem('psychometric-assessment');
          if (!savedData) return false;

          const data = JSON.parse(savedData);
          
          set({
            ...data,
            lastUpdated: new Date(),
            hexacoResponseValidity: data.hexacoResponses?.map((r: any) => r.response >= 0) || Array(60).fill(false),
            dassResponseValidity: data.dassResponses?.map((r: any) => r.response >= 0) || Array(21).fill(false),
            scoringCache: {
              hexacoScores: data.hexacoScores || null,
              dassScores: data.dassScores || null,
              stabilityFlags: data.stabilityFlags || null,
            },
          });
          
          return true;
        } catch (error) {
          console.error('Error loading from localStorage:', error);
          return false;
        }
      },

      clearLocalStorage: () => {
        try {
          localStorage.removeItem('psychometric-assessment');
          return true;
        } catch (error) {
          console.error('Error clearing localStorage:', error);
          return false;
        }
      },
    }),
    {
      name: 'psychometric-store',
    }
  )
);

// Selectors for optimized re-renders
export const useHexacoResponses = () => usePsychometricStore((state) => state.hexacoResponses);
export const useDassResponses = () => usePsychometricStore((state) => state.dassResponses);
export const useHexacoScores = () => usePsychometricStore((state) => state.hexacoScores);
export const useDassScores = () => usePsychometricStore((state) => state.dassScores);
export const useStabilityFlags = () => usePsychometricStore((state) => state.stabilityFlags);
export const useProgress = () => usePsychometricStore((state) => ({
  hexaco: state.hexacoProgress,
  dass: state.dassProgress,
  total: state.totalProgress,
}));
export const useCurrentQuestion = () => usePsychometricStore((state) => ({
  scale: state.currentScale,
  question: state.currentQuestion,
  section: state.currentSection,
}));
export const useAssessmentStatus = () => usePsychometricStore((state) => ({
  isComplete: state.isComplete,
  isValid: state.isValid,
  startedAt: state.startedAt,
  completedAt: state.completedAt,
}));
