import type { 
  HEXACOResponse, 
  DASSResponse, 
  HEXACOScores, 
  DASSScores, 
  StabilityFlags,
  ScoringInput,
  ScoringOutput,
  HEXACOItem,
  DASSItem
} from '../types/psychometric';

// HEXACO-60 Item Configuration with reverse-coding
export const HEXACO_ITEMS: HEXACOItem[] = [
  // Honesty-Humility (Items 1-10)
  { id: 1, facet: 'HonestyHumility', text: "I feel that I am an honest person.", reverseCoded: false },
  { id: 2, facet: 'HonestyHumility', text: "I think that I am entitled to more respect than the average person.", reverseCoded: true },
  { id: 3, facet: 'HonestyHumility', text: "I would be tempted to buy stolen property if I were sure I would not be caught.", reverseCoded: true },
  { id: 4, facet: 'HonestyHumility', text: "I would never accept a bribe, even if it were a large amount.", reverseCoded: false },
  { id: 5, facet: 'HonestyHumility', text: "If I want something from someone, I will laugh at that person's worst jokes.", reverseCoded: true },
  { id: 6, facet: 'HonestyHumility', text: "I feel like a superior person.", reverseCoded: true },
  { id: 7, facet: 'HonestyHumility', text: "If I knew that I could get away with it, I would like to take a credit for someone else's work.", reverseCoded: true },
  { id: 8, facet: 'HonestyHumility', text: "I would get a lot of pleasure from owning expensive luxury goods.", reverseCoded: true },
  { id: 9, facet: 'HonestyHumility', text: "I want people to know that I am an important person of high status.", reverseCoded: true },
  { id: 10, facet: 'HonestyHumility', text: "I would never cheat on my taxes.", reverseCoded: false },
  
  // Emotionality (Items 11-20)
  { id: 11, facet: 'Emotionality', text: "I feel afraid when I have to travel in bad weather conditions.", reverseCoded: false },
  { id: 12, facet: 'Emotionality', text: "I react emotionally to music.", reverseCoded: false },
  { id: 13, facet: 'Emotionality', text: " I rarely feel fearful.", reverseCoded: true },
  { id: 14, facet: 'Emotionality', text: " I often worry about things that might go wrong.", reverseCoded: false },
  { id: 15, facet: 'Emotionality', text: " I avoid dangerous situations.", reverseCoded: false },
  { id: 16, facet: 'Emotionality', text: " I keep my cool under pressure.", reverseCoded: true },
  { id: 17, facet: 'Emotionality', text: " I rarely feel anxious.", reverseCoded: true },
  { id: 18, facet: 'Emotionality', text: " I often feel sad.", reverseCoded: false },
  { id: 19, facet: 'Emotionality', text: " I am not deeply moved by emotional events.", reverseCoded: true },
  { id: 20, facet: 'Emotionality', text: " I need people to tell me that I have done well before I feel good about myself.", reverseCoded: false },
  
  // Extraversion (Items 21-30)
  { id: 21, facet: 'Extraversion', text: "I feel that I am a person who is outgoing and sociable.", reverseCoded: false },
  { id: 22, facet: 'Extraversion', text: "I like to be where the action is.", reverseCoded: false },
  { id: 23, facet: 'Extraversion', text: "I often feel as if I am bursting with energy.", reverseCoded: false },
  { id: 24, facet: 'Extraversion', text: "I would rather go my own way than follow a crowd.", reverseCoded: true },
  { id: 25, facet: 'Extraversion', text: "I prefer jobs that involve active social interaction.", reverseCoded: false },
  { id: 26, facet: 'Extraversion', text: "I try to lead others.", reverseCoded: false },
  { id: 27, facet: 'Extraversion', text: "I am the first to act.", reverseCoded: false },
  { id: 28, facet: 'Extraversion', text: "I am known as 'the life of the party'.", reverseCoded: false },
  { id: 29, facet: 'Extraversion', text: "I feel comfortable around people.", reverseCoded: false },
  { id: 30, facet: 'Extraversion', text: "I keep in the background.", reverseCoded: true },
  
  // Agreeableness (Items 31-40)
  { id: 31, facet: 'Agreeableness', text: "I am interested in people.", reverseCoded: false },
  { id: 32, facet: 'Agreeableness', text: "I avoid arguments with others.", reverseCoded: false },
  { id: 33, facet: 'Agreeableness', text: "I try not to think about the needy people.", reverseCoded: true },
  { id: 34, facet: 'Agreeableness', text: "I sympathize with others' feelings.", reverseCoded: false },
  { id: 35, facet: 'Agreeableness', text: "I am not interested in other people's problems.", reverseCoded: true },
  { id: 36, facet: 'Agreeableness', text: "I am not really interested in others.", reverseCoded: true },
  { id: 37, facet: 'Agreeableness', text: "I take time out for others.", reverseCoded: false },
  { id: 38, facet: 'Agreeableness', text: "I feel other people's emotions.", reverseCoded: false },
  { id: 39, facet: 'Agreeableness', text: "I make people feel at ease.", reverseCoded: false },
  { id: 40, facet: 'Agreeableness', text: "I rarely feel sympathy for people who are worse off than myself.", reverseCoded: true },
  
  // Conscientiousness (Items 41-50)
  { id: 41, facet: 'Conscientiousness', text: "I always keep my promises.", reverseCoded: false },
  { id: 42, facet: 'Conscientiousness', text: "I work hard to accomplish my goals.", reverseCoded: false },
  { id: 43, facet: 'Conscientiousness', text: "I am prepared for most eventualities.", reverseCoded: false },
  { id: 44, facet: 'Conscientiousness', text: "I pay attention to details.", reverseCoded: false },
  { id: 45, facet: 'Conscientiousness', text: "I get chores done right away.", reverseCoded: false },
  { id: 46, facet: 'Conscientiousness', text: "I often forget to put things back in their proper place.", reverseCoded: true },
  { id: 47, facet: 'Conscientiousness', text: " I like order.", reverseCoded: false },
  { id: 48, facet: 'Conscientiousness', text: " I shirk my duties.", reverseCoded: true },
  { id: 49, facet: 'Conscientiousness', text: " I make a mess of things.", reverseCoded: true },
  { id: 50, facet: 'Conscientiousness', text: " I often feel overwhelmed by many different tasks.", reverseCoded: true },
  
  // Openness to Experience (Items 51-60)
  { id: 51, facet: 'OpennessToExperience', text: "I am fascinated by new ideas.", reverseCoded: false },
  { id: 52, facet: 'OpennessToExperience', text: "I am interested in learning about other cultures.", reverseCoded: false },
  { id: 53, facet: 'OpennessToExperience', text: "I avoid philosophical discussions.", reverseCoded: true },
  { id: 54, facet: 'OpennessToExperience', text: "I do not like art.", reverseCoded: true },
  { id: 55, facet: 'OpennessToExperience', text: "I do not enjoy going to art museums.", reverseCoded: true },
  { id: 56, facet: 'OpennessToExperience', text: "I avoid difficult reading material.", reverseCoded: true },
  { id: 57, facet: 'OpennessToExperience', text: "I do not like poetry.", reverseCoded: true },
  { id: 58, facet: 'OpennessToExperience', text: " I enjoy looking at paintings.", reverseCoded: false },
  { id: 59, facet: 'OpennessToExperience', text: " I enjoy hearing new ideas.", reverseCoded: false },
  { id: 60, facet: 'OpennessToExperience', text: " I enjoy wild flights of fantasy.", reverseCoded: false },
];

// DASS-21 Item Configuration
export const DASS_ITEMS: DASSItem[] = [
  // Depression Items (D)
  { id: 1, scale: 'Depression', text: "I found it hard to wind down" },
  { id: 2, scale: 'Depression', text: "I tended to over-react to situations" },
  { id: 3, scale: 'Depression', text: "I felt that I was using a lot of nervous energy" },
  { id: 4, scale: 'Depression', text: "I found myself getting agitated" },
  { id: 5, scale: 'Depression', text: "I found it difficult to relax" },
  { id: 6, scale: 'Depression', text: "I tended to feel that there was nothing to look forward to" },
  { id: 7, scale: 'Depression', text: "I felt that I was rather slow" },
  { id: 8, scale: 'Depression', text: "I felt that I had lost interest in just about everything" },
  { id: 9, scale: 'Depression', text: "I felt I wasn't worth much as a person" },
  { id: 10, scale: 'Depression', text: "I felt that life was meaningless" },
  
  // Anxiety Items (A)
  { id: 11, scale: 'Anxiety', text: "I felt that I was close to panic" },
  { id: 12, scale: 'Anxiety', text: "I was aware of the action of my heart in the absence of physical exertion" },
  { id: 13, scale: 'Anxiety', text: "I felt scared without any good reason" },
  { id: 14, scale: 'Anxiety', text: "I felt terrified" },
  { id: 15, scale: 'Anxiety', text: "I felt that I was going to faint" },
  { id: 16, scale: 'Anxiety', text: "I felt that life was hopeless" },
  { id: 17, scale: 'Anxiety', text: "I was worried about situations in which I might panic and make a fool of myself" },
  { id: 18, scale: 'Anxiety', text: "I experienced trembling (e.g., in the hands)" },
  { id: 19, scale: 'Anxiety', text: "I felt that I was nervous" },
  { id: 20, scale: 'Anxiety', text: "I felt that everything was an effort" },
  
  // Stress Items (S)
  { id: 21, scale: 'Stress', text: "I found it difficult to breathe" },
];

export class ScoringAlgorithm {
  /**
   * Calculate HEXACO-60 scores with reverse-coding
   */
  static calculateHEXACOScores(responses: HEXACOResponse[]): HEXACOScores {
    const facetScores = {
      HonestyHumility: 0,
      Emotionality: 0,
      Extraversion: 0,
      Agreeableness: 0,
      Conscientiousness: 0,
      OpennessToExperience: 0,
    };

    const facetCounts = {
      HonestyHumility: 0,
      Emotionality: 0,
      Extraversion: 0,
      Agreeableness: 0,
      Conscientiousness: 0,
      OpennessToExperience: 0,
    };

    // Process each response
    responses.forEach(response => {
      const item = HEXACO_ITEMS.find(item => item.id === response.id);
      if (!item) return;

      let score = response.response;
      
      // Apply reverse-coding if needed
      if (item.reverseCoded) {
        score = 5 - score; // Reverse code: 0->5, 1->4, 2->3, 3->2, 4->1, 5->0
      }

      facetScores[item.facet] += score;
      facetCounts[item.facet]++;
    });

    // Calculate average scores for each facet
    const finalScores: HEXACOScores = {
      HonestyHumility: facetCounts.HonestyHumility > 0 ? facetScores.HonestyHumility / facetCounts.HonestyHumility : 0,
      Emotionality: facetCounts.Emotionality > 0 ? facetScores.Emotionality / facetCounts.Emotionality : 0,
      Extraversion: facetCounts.Extraversion > 0 ? facetScores.Extraversion / facetCounts.Extraversion : 0,
      Agreeableness: facetCounts.Agreeableness > 0 ? facetScores.Agreeableness / facetCounts.Agreeableness : 0,
      Conscientiousness: facetCounts.Conscientiousness > 0 ? facetScores.Conscientiousness / facetCounts.Conscientiousness : 0,
      OpennessToExperience: facetCounts.OpennessToExperience > 0 ? facetScores.OpennessToExperience / facetCounts.OpennessToExperience : 0,
    };

    return finalScores;
  }

  /**
   * Calculate DASS-21 scores with scaling (sum * 2)
   */
  static calculateDASSScores(responses: DASSResponse[]): DASSScores {
    const scaleScores = {
      Depression: 0,
      Anxiety: 0,
      Stress: 0,
    };

    // Process each response
    responses.forEach(response => {
      const item = DASS_ITEMS.find(item => item.id === response.id);
      if (!item) return;

      scaleScores[item.scale] += response.response;
    });

    // Apply scaling factor (multiply by 2 to align with DASS-42)
    const finalScores: DASSScores = {
      Depression: scaleScores.Depression * 2,
      Anxiety: scaleScores.Anxiety * 2,
      Stress: scaleScores.Stress * 2,
    };

    return finalScores;
  }

  /**
   * Calculate Stability Index with cross-correlation analysis
   */
  static calculateStabilityIndex(hexacoScores: HEXACOScores, dassScores: DASSScores): StabilityFlags {
    const flags: StabilityFlags = {
      acuteReactiveState: false,
      highFunctioningBurnout: false,
      overallStability: 'Stable',
    };

    // Acute Reactive State: High stress + high emotionality
    if (dassScores.Stress > 24 && hexacoScores.Emotionality > 4.2) {
      flags.acuteReactiveState = true;
    }

    // High-Functioning Burnout: High conscientiousness + high depression
    if (hexacoScores.Conscientiousness > 4.5 && dassScores.Depression > 15) {
      flags.highFunctioningBurnout = true;
    }

    // Determine overall stability
    const riskFactors = [
      flags.acuteReactiveState,
      flags.highFunctioningBurnout,
      dassScores.Depression > 20,
      dassScores.Anxiety > 20,
      dassScores.Stress > 25,
      hexacoScores.Emotionality > 4.5,
      hexacoScores.Conscientiousness < 2.0,
    ];

    const riskCount = riskFactors.filter(Boolean).length;

    if (riskCount >= 3) {
      flags.overallStability = 'Critical';
    } else if (riskCount >= 1) {
      flags.overallStability = 'At Risk';
    } else {
      flags.overallStability = 'Stable';
    }

    return flags;
  }

  /**
   * Complete scoring algorithm
   */
  static calculateScores(input: ScoringInput): ScoringOutput {
    const hexacoScores = this.calculateHEXACOScores(input.hexacoResponses);
    const dassScores = this.calculateDASSScores(input.dassResponses);
    const stabilityFlags = this.calculateStabilityIndex(hexacoScores, dassScores);

    return {
      hexacoScores,
      dassScores,
      stabilityFlags,
    };
  }

  /**
   * Get HEXACO item by ID
   */
  static getHexacoItem(id: number): HEXACOItem | undefined {
    return HEXACO_ITEMS.find(item => item.id === id);
  }

  /**
   * Get DASS item by ID
   */
  static getDassItem(id: number): DASSItem | undefined {
    return DASS_ITEMS.find(item => item.id === id);
  }

  /**
   * Get all HEXACO items for a specific facet
   */
  static getHexacoItemsByFacet(facet: keyof HEXACOScores): HEXACOItem[] {
    return HEXACO_ITEMS.filter(item => item.facet === facet);
  }

  /**
   * Get all DASS items for a specific scale
   */
  static getDassItemsByScale(scale: keyof DASSScores): DASSItem[] {
    return DASS_ITEMS.filter(item => item.scale === scale);
  }

  /**
   * Validate response completeness
   */
  static validateResponseCompleteness(hexacoResponses: HEXACOResponse[], dassResponses: DASSResponse[]): {
    isHexacoComplete: boolean;
    isDassComplete: boolean;
    isComplete: boolean;
    missingHexaco: number[];
    missingDass: number[];
  } {
    const expectedHexacoIds = Array.from({ length: 60 }, (_, i) => i + 1);
    const expectedDassIds = Array.from({ length: 21 }, (_, i) => i + 1);

    const providedHexacoIds = hexacoResponses.map(r => r.id);
    const providedDassIds = dassResponses.map(r => r.id);

    const missingHexaco = expectedHexacoIds.filter(id => !providedHexacoIds.includes(id));
    const missingDass = expectedDassIds.filter(id => !providedDassIds.includes(id));

    return {
      isHexacoComplete: missingHexaco.length === 0,
      isDassComplete: missingDass.length === 0,
      isComplete: missingHexaco.length === 0 && missingDass.length === 0,
      missingHexaco,
      missingDass,
    };
  }
}
