// HEXACO-60 Response Types
export interface HEXACOResponse {
  id: number;
  response: number; // 0-5 Likert scale
}

export interface HEXACOScores {
  HonestyHumility: number;
  Emotionality: number;
  Extraversion: number;
  Agreeableness: number;
  Conscientiousness: number;
  OpennessToExperience: number;
}

// DASS-21 Response Types
export interface DASSResponse {
  id: number;
  response: number; // 0-3 Likert scale (0=Never, 1=Sometimes, 2=Often, 3=Almost Always)
}

export interface DASSScores {
  Depression: number;
  Anxiety: number;
  Stress: number;
}

// Stability Index Types
export interface StabilityFlags {
  acuteReactiveState: boolean;
  highFunctioningBurnout: boolean;
  overallStability: 'Stable' | 'At Risk' | 'Critical';
}

// Complete Psychometric Profile
export interface PsychometricProfile {
  // HEXACO-60 Responses (60 items)
  hexacoResponses: HEXACOResponse[];
  
  // DASS-21 Responses (21 items)  
  dassResponses: DASSResponse[];
  
  // Calculated Scores
  hexacoScores: HEXACOScores;
  dassScores: DASSScores;
  
  // Stability Analysis
  stabilityFlags: StabilityFlags;
  
  // Metadata
  completedAt: Date | null;
  lastUpdated: Date | null;
  isValid: boolean;
}

// Individual Response Validation
export interface PsychometricResponse {
  questionId: number;
  scale: 'hexaco' | 'dass';
  value: number;
}

// Scoring Algorithm Input/Output
export interface ScoringInput {
  hexacoResponses: HEXACOResponse[];
  dassResponses: DASSResponse[];
}

export interface ScoringOutput {
  hexacoScores: HEXACOScores;
  dassScores: DASSScores;
  stabilityFlags: StabilityFlags;
}

// Store State Interface
export interface PsychometricState {
  // Response Storage
  hexacoResponses: HEXACOResponse[];
  dassResponses: DASSResponse[];
  
  // Computed Scores
  hexacoScores: HEXACOScores | null;
  dassScores: DASSScores | null;
  stabilityFlags: StabilityFlags | null;
  
  // UI State
  currentScale: 'hexaco' | 'dass' | null;
  currentQuestion: number;
  isComplete: boolean;
  isValid: boolean;
  
  // Metadata
  startedAt: Date | null;
  completedAt: Date | null;
  lastUpdated: Date | null;
  
  // Actions
  setHexacoResponse: (id: number, response: number) => void;
  setDassResponse: (id: number, response: number) => void;
  setHexacoResponses: (responses: HEXACOResponse[]) => void;
  setDassResponses: (responses: DASSResponse[]) => void;
  calculateScores: () => void;
  resetAssessment: () => void;
  setCurrentScale: (scale: 'hexaco' | 'dass') => void;
  setCurrentQuestion: (question: number) => void;
  validateResponses: () => boolean;
}

// HEXACO-60 Item Configuration
export interface HEXACOItem {
  id: number;
  facet: keyof HEXACOScores;
  text: string;
  reverseCoded: boolean;
}

// DASS-21 Item Configuration  
export interface DASSItem {
  id: number;
  scale: keyof DASSScores;
  text: string;
}

// Validation Error Types
export interface ValidationError {
  field: string;
  message: string;
  value: any;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}
